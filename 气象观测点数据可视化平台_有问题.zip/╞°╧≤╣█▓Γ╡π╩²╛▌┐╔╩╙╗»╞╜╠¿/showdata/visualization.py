import datasrc
import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Line, Scatter
import os

# 可靠度分级
real_grade = ['4', '3', '2', '1', '0']
conf_grade = {key: real_grade[0] for key in ['0', '1', '4', '5', '9']}
conf_grade.update({key: real_grade[1] for key in ['A', 'C', 'I', 'M', 'P', 'R', 'U']})
conf_grade.update({key: real_grade[2] for key in ['2', '6']})
conf_grade.update({key: real_grade[3] for key in ['3', '7']})
conf_grade.update({key: real_grade[4] for key in ['0']})

# 获取特定气象站全部的的气象数据，考虑到代码的复用定义了这个函数
def alltime(stat):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    mysqlite = datasrc.SqliteTool()
    # 执行查询语句
    mysqlite._cur.execute("select * from datasource where substr(stat_date, 1, 11) = ?", (stat,))
    # 获取查询结果
    result = mysqlite._cur.fetchall()
    # 获取查询的字段名
    columns = [desc[0] for desc in mysqlite._cur.description]
    # 使用查询结果和字段名创建 DataFrame
    df = pd.DataFrame(result, columns=columns)
    # 关闭游标和连接
    mysqlite.close_con()
    return df

# 获取指定时间段的气象数据，考虑到代码的复用定义了这个函数
def spectime(stat, begin, end):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    mysqlite = datasrc.SqliteTool()
    newend = end[:-2] + ('0' if len(str(int(end[-2:]) + 1)) == 1 else '') + str(int(end[-2:]) + 1)  # 结束日期要加1
    # 执行查询语句
    # print(((stat + ',' + begin), (stat + ',' + newend)))
    mysqlite._cur.execute("select * from datasource where stat_date between ? and ?",
                          ((stat + ',' + begin), (stat + ',' + newend)))
    # 获取查询结果
    result = mysqlite._cur.fetchall()
    # 获取查询的字段名
    columns = [desc[0] for desc in mysqlite._cur.description]
    # 使用查询结果和字段名创建 DataFrame
    df = pd.DataFrame(result, columns=columns)
    # 关闭游标和连接
    mysqlite.close_con()
    return df

# 展示指定站点在指定时间段的露点数据
def showdew(stat, begin="", end=""):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    if(begin=="" or end==""):
        df = alltime(stat)
    else:
        df = spectime(stat, begin, end)
    print(df)
    conf = []
    # 准备数据
    x_data = [(iter.split(',')[1]).split('T')[0] + '日' + (iter.split(',')[1]).split('T')[1][:2] + '时' for iter in df['stat_date']]
    y_data = [int(iter.split(',')[0])/10 for iter in df['dew']]
    for i in range(len(df['dew'])):
        fir = int((df['dew'][i]).split(',')[0])
        sec = (df['dew'][i]).split(',')[1]
        conf.append(conf_grade[sec] if (fir != 9999) else conf_grade['0'])
    # 创建 Line 图表
    line_date = Line()
    # line_conf = Line()
    line_conf = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_date.add_xaxis(xaxis_data=x_data)
    line_date.add_yaxis(series_name='露点数据(°C)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False), yaxis_index=0)
    line_date.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    line_conf.add_xaxis(xaxis_data=x_data)
    line_conf.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4, label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_date.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n露点数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}°C")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_conf.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_date.overlap(line_conf)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok = True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>露点数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_date.render_embed()}
        </div>
    </body>
    </html>
    '''
    os.makedirs(current_directory + '/html/' + stat + '/', exist_ok=True)
    with open(current_directory + '/html/' + stat + '/dew.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
# showdew('55279099999', '2022-12-03', '2023-12-05')

# 展示指定站点在指定时间段的海平面压力数据
def showslp(stat, begin="", end=""):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    if(begin=="" or end==""):
        df = alltime(stat)
    else:
        df = spectime(stat, begin, end)
    conf = []
    # 准备数据
    x_data = [(iter.split(',')[1]).split('T')[0] + '日' + (iter.split(',')[1]).split('T')[1][:2] + '时'  for iter in df['stat_date']]
    y_data = [int(iter.split(',')[0])/10 for iter in df['slp']]
    for i in range(len(df['slp'])):
        fir = int((df['slp'][i]).split(',')[0])
        sec = (df['slp'][i]).split(',')[1]
        conf.append(conf_grade[sec] if (fir != 99999) else conf_grade['0'])
    # 创建 Line 图表
    line_date = Line()
    # line_conf = Line()
    line_conf = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_date.add_xaxis(xaxis_data=x_data)
    line_date.add_yaxis(series_name='气压数据(hPa)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False), yaxis_index=0)
    line_date.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    line_conf.add_xaxis(xaxis_data=x_data)
    line_conf.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4, label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_date.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n气压数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}hPa")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_conf.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_date.overlap(line_conf)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok = True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>气压数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_date.render_embed()}
        </div>
    </body>
    </html>
    '''
    with open(current_directory + '/html/' + stat + '/slp.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
# showslp('55279099999', '2022-12-03', '2023-12-05')

# 展示指定站点在指定时间段的温度数据
def showtmp(stat, begin="", end=""):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    if(begin=="" or end==""):
        df = alltime(stat)
    else:
        df = spectime(stat, begin, end)
    conf = []
    # 准备数据
    x_data = [(iter.split(',')[1]).split('T')[0] + '日' + (iter.split(',')[1]).split('T')[1][:2] + '时' for iter in
              df['stat_date']]
    y_data = [int(iter.split(',')[0]) / 10 for iter in df['tmp']]
    for i in range(len(df['tmp'])):
        fir = int((df['tmp'][i]).split(',')[0])
        sec = (df['tmp'][i]).split(',')[1]
        conf.append(conf_grade[sec] if (fir != 9999) else conf_grade['0'])
    # 创建 Line 图表
    line_date = Line()
    line_conf = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_date.add_xaxis(xaxis_data=x_data)
    line_date.add_yaxis(series_name='气温数据(°C)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False), yaxis_index=0)
    line_date.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    line_conf.add_xaxis(xaxis_data=x_data)
    line_conf.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4,
                        label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_date.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n气温数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}°C")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_conf.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_date.overlap(line_conf)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok=True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>气温数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_date.render_embed()}
        </div>
    </body>
    </html>
    '''
    with open(current_directory + '/html/' + stat + '/tmp.html', 'w', encoding='utf-8') as f:
        f.write(html_content)

# showtmp('55279099999', '2022-12-03', '2023-12-05')

# 展示指定站点在指定时间段的可见度数据
def showvis(stat, begin="", end=""):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    if(begin=="" or end==""):
        df = alltime(stat)
    else:
        df = spectime(stat, begin, end)
    conf = []
    # 准备数据
    x_data = [(iter.split(',')[1]).split('T')[0] + '日' + (iter.split(',')[1]).split('T')[1][:2] + '时' for iter in
              df['stat_date']]
    y_data = [int(iter.split(',')[0]) for iter in df['vis']]
    for i in range(len(df['vis'])):
        fir = int((df['vis'][i]).split(',')[0])
        sec = (df['vis'][i]).split(',')[1]
        conf.append(conf_grade[sec] if (fir != 999999) else conf_grade['0'])
    # 创建 Line 图表
    line_date = Line()
    # line_conf = Line()
    line_conf = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_date.add_xaxis(xaxis_data=x_data)
    line_date.add_yaxis(series_name='可视距离数据(m)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False), yaxis_index=0)
    line_date.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    line_conf.add_xaxis(xaxis_data=x_data)
    line_conf.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4,
                        label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_date.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n可视距离数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}m")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_conf.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_date.overlap(line_conf)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok=True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>可视距离数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_date.render_embed()}
        </div>
    </body>
    </html>
    '''
    with open(current_directory + '/html/' + stat + '/vis.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
# showvis('55279099999', '2022-12-03', '2023-12-05')

# 展示指定站点在指定时间段的风速数据
def showwnd(stat, begin="", end=""):
    '''
    stat: 站点编号，字符串
    begin: 开始日期，传入形式为字符串，格式为“xxxx-xx-xx”
    end: 结束日期，传入形式为字符串，格式为“xxxx-xx-xx”
    '''
    if(begin=="" or end==""):
        df = alltime(stat)
    else:
        df = spectime(stat, begin, end)
    conf = []
    # 准备数据，制作风向数据展示图
    x_data = [(iter.split(',')[1]).split('T')[0] + '日' + (iter.split(',')[1]).split('T')[1][:2] + '时' for iter in
              df['stat_date']]
    y_data = [int(iter.split(',')[0]) for iter in df['wnd']]
    for i in range(len(df['wnd'])):
        fir = int((df['wnd'][i]).split(',')[0])
        sec = (df['wnd'][i]).split(',')[1]
        conf.append(conf_grade[sec] if (fir != 999) else conf_grade['0'])
    # 创建 Line 图表
    line_dire = Line()
    # line_conf = Line()
    conf_dire = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_dire.add_xaxis(xaxis_data=x_data)
    line_dire.add_yaxis(series_name='风向数据(°, 从正北方向顺时针开始)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False), yaxis_index=0)
    line_dire.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    conf_dire.add_xaxis(xaxis_data=x_data)
    conf_dire.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4,
                        label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_dire.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n风向数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}m")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    conf_dire.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_dire.overlap(conf_dire)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok=True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>风向数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_dire.render_embed()}
        </div>
    </body>
    </html>
    '''
    with open(current_directory + '/html/' + stat + '/wnddire.html', 'w', encoding='utf-8') as f:
        f.write(html_content)

    # 数据准备，制作风速数据展示图
    conf = []
    y_data = []
    for i in range(len(df['wnd'])):
        fir = int((df['wnd'][i]).split(',')[3])
        y_data.append(fir)
        sec = (df['wnd'][i]).split(',')[4]
        conf.append(conf_grade[sec] if (fir != 9999) else conf_grade['0'])
    # 创建 Line 图表
    line_sped = Line()
    # line_conf = Line()
    conf_sped = Scatter()  # 使用 Scatter 类型来表示散点图
    # 添加数据
    line_sped.add_xaxis(xaxis_data=x_data)
    line_sped.add_yaxis(series_name='风速数据(m/s)', y_axis=y_data, label_opts=opts.LabelOpts(is_show=False),
                        yaxis_index=0)
    line_sped.extend_axis(yaxis=opts.AxisOpts(axisline_opts=opts.AxisLineOpts()))  # 添加一条蓝色的y轴
    conf_sped.add_xaxis(xaxis_data=x_data)
    conf_sped.add_yaxis(series_name='可信度', y_axis=conf, symbol='circle', symbol_size=4,
                        label_opts=opts.LabelOpts(is_show=False), yaxis_index=1)
    # 设置图表标题和其他配置
    line_sped.set_global_opts(
        title_opts=opts.TitleOpts(title='站点编号' + stat + '(' + df['name'].loc[0] + ')' + '\n风速数据展示'),
        xaxis_opts=opts.AxisOpts(type_='category'),
        yaxis_opts=opts.AxisOpts(type_='value', axislabel_opts=opts.LabelOpts(formatter="{value}m")),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    conf_sped.set_global_opts(
        yaxis_opts=opts.AxisOpts(type_="category"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        legend_opts=opts.LegendOpts(orient="vertical", pos_left="right", pos_top="top")
    )
    line_sped.overlap(conf_sped)
    # 渲染图表到 HTML 文件
    current_directory = os.path.dirname(os.path.realpath(__file__))
    os.makedirs(current_directory + '/html', exist_ok=True)
    html_content = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>风速数据</title>
        <style>
            body {{
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
            }}
            #chart-container {{
                width: 80%;
                height: 80%;
            }}
        </style>
    </head>
    <body>
        <div id="chart-container">
            {line_sped.render_embed()}
        </div>
    </body>
    </html>
    '''
    with open(current_directory + '/html/' + stat + '/wndsped.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
# showwnd('55279099999', '2022-12-03', '2023-12-05')

# 在html文件夹下生成所有站点的六类数据展示图，路径格式为"/html/站点编号/xx.html"
def all_htmls():
    mysqlite = datasrc.SqliteTool()
    df = mysqlite.db2df()
    # print(df)
    df_set = set(item.split(',')[0] for item in df['stat_date'])
    print(df_set)
    for stat in df_set:
        showdew(stat)
        showslp(stat)
        showtmp(stat)
        showvis(stat)
        showwnd(stat)
all_htmls()