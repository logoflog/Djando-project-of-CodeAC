"""气象观测点数据可视化平台 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from myapp import views
from django.contrib import admin
from django.urls import re_path

urlpatterns = [
    path('', views.welcome, name='welcome'),
    path('datashow/', views.datashow),
    path('download/', views.download),
    path('administrator/', admin.site.urls, name='administrator'),
    path('login/', views.do_login, name='login'),
    path('register/', views.do_reg, name='register'),
    re_path(r'^logout$', views.do_logout, name='logout'),
]
